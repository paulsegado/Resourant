package com.example.restourant.activity;

public class MainActivity {
}
